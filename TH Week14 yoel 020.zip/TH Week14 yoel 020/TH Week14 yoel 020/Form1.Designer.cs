﻿namespace TH_Week14_yoel_020
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_matchid = new System.Windows.Forms.Label();
            this.lbl_thome = new System.Windows.Forms.Label();
            this.lbl_matchdate = new System.Windows.Forms.Label();
            this.lbl_taway = new System.Windows.Forms.Label();
            this.lbl_minute = new System.Windows.Forms.Label();
            this.lbl_team = new System.Windows.Forms.Label();
            this.lbl_player = new System.Windows.Forms.Label();
            this.lbl_type = new System.Windows.Forms.Label();
            this.tb_matchid = new System.Windows.Forms.TextBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.cb_thome = new System.Windows.Forms.ComboBox();
            this.cb_taway = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_matchid
            // 
            this.lbl_matchid.AutoSize = true;
            this.lbl_matchid.Location = new System.Drawing.Point(12, 9);
            this.lbl_matchid.Name = "lbl_matchid";
            this.lbl_matchid.Size = new System.Drawing.Size(51, 13);
            this.lbl_matchid.TabIndex = 0;
            this.lbl_matchid.Text = "Match ID";
            // 
            // lbl_thome
            // 
            this.lbl_thome.AutoSize = true;
            this.lbl_thome.Location = new System.Drawing.Point(12, 44);
            this.lbl_thome.Name = "lbl_thome";
            this.lbl_thome.Size = new System.Drawing.Size(65, 13);
            this.lbl_thome.TabIndex = 1;
            this.lbl_thome.Text = "Team Home";
            // 
            // lbl_matchdate
            // 
            this.lbl_matchdate.AutoSize = true;
            this.lbl_matchdate.Location = new System.Drawing.Point(259, 9);
            this.lbl_matchdate.Name = "lbl_matchdate";
            this.lbl_matchdate.Size = new System.Drawing.Size(63, 13);
            this.lbl_matchdate.TabIndex = 2;
            this.lbl_matchdate.Text = "Match Date";
            // 
            // lbl_taway
            // 
            this.lbl_taway.AutoSize = true;
            this.lbl_taway.Location = new System.Drawing.Point(259, 44);
            this.lbl_taway.Name = "lbl_taway";
            this.lbl_taway.Size = new System.Drawing.Size(63, 13);
            this.lbl_taway.TabIndex = 3;
            this.lbl_taway.Text = "Team Away";
            // 
            // lbl_minute
            // 
            this.lbl_minute.AutoSize = true;
            this.lbl_minute.Location = new System.Drawing.Point(377, 119);
            this.lbl_minute.Name = "lbl_minute";
            this.lbl_minute.Size = new System.Drawing.Size(39, 13);
            this.lbl_minute.TabIndex = 4;
            this.lbl_minute.Text = "Minute";
            // 
            // lbl_team
            // 
            this.lbl_team.AutoSize = true;
            this.lbl_team.Location = new System.Drawing.Point(377, 148);
            this.lbl_team.Name = "lbl_team";
            this.lbl_team.Size = new System.Drawing.Size(34, 13);
            this.lbl_team.TabIndex = 5;
            this.lbl_team.Text = "Team";
            // 
            // lbl_player
            // 
            this.lbl_player.AutoSize = true;
            this.lbl_player.Location = new System.Drawing.Point(377, 176);
            this.lbl_player.Name = "lbl_player";
            this.lbl_player.Size = new System.Drawing.Size(36, 13);
            this.lbl_player.TabIndex = 6;
            this.lbl_player.Text = "Player";
            // 
            // lbl_type
            // 
            this.lbl_type.AutoSize = true;
            this.lbl_type.Location = new System.Drawing.Point(377, 206);
            this.lbl_type.Name = "lbl_type";
            this.lbl_type.Size = new System.Drawing.Size(31, 13);
            this.lbl_type.TabIndex = 7;
            this.lbl_type.Text = "Type";
            // 
            // tb_matchid
            // 
            this.tb_matchid.Location = new System.Drawing.Point(82, 6);
            this.tb_matchid.Name = "tb_matchid";
            this.tb_matchid.Size = new System.Drawing.Size(133, 20);
            this.tb_matchid.TabIndex = 8;
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(422, 112);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(133, 20);
            this.tb_minute.TabIndex = 9;
            // 
            // cb_thome
            // 
            this.cb_thome.FormattingEnabled = true;
            this.cb_thome.Location = new System.Drawing.Point(82, 41);
            this.cb_thome.Name = "cb_thome";
            this.cb_thome.Size = new System.Drawing.Size(131, 21);
            this.cb_thome.TabIndex = 10;
            this.cb_thome.SelectedIndexChanged += new System.EventHandler(this.cb_thome_SelectedIndexChanged);
            // 
            // cb_taway
            // 
            this.cb_taway.FormattingEnabled = true;
            this.cb_taway.Location = new System.Drawing.Point(328, 41);
            this.cb_taway.Name = "cb_taway";
            this.cb_taway.Size = new System.Drawing.Size(131, 21);
            this.cb_taway.TabIndex = 11;
            this.cb_taway.SelectedIndexChanged += new System.EventHandler(this.cb_taway_SelectedIndexChanged);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(422, 140);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(131, 21);
            this.cb_team.TabIndex = 12;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(422, 173);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(131, 21);
            this.cb_player.TabIndex = 13;
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(422, 203);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(131, 21);
            this.cb_type.TabIndex = 14;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(328, 9);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 15;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 102);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(345, 181);
            this.dataGridView1.TabIndex = 16;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(480, 243);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 17;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(384, 243);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 18;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(247, 301);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(111, 23);
            this.btn_insert.TabIndex = 19;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_taway);
            this.Controls.Add(this.cb_thome);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.tb_matchid);
            this.Controls.Add(this.lbl_type);
            this.Controls.Add(this.lbl_player);
            this.Controls.Add(this.lbl_team);
            this.Controls.Add(this.lbl_minute);
            this.Controls.Add(this.lbl_taway);
            this.Controls.Add(this.lbl_matchdate);
            this.Controls.Add(this.lbl_thome);
            this.Controls.Add(this.lbl_matchid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_matchid;
        private System.Windows.Forms.Label lbl_thome;
        private System.Windows.Forms.Label lbl_matchdate;
        private System.Windows.Forms.Label lbl_taway;
        private System.Windows.Forms.Label lbl_minute;
        private System.Windows.Forms.Label lbl_team;
        private System.Windows.Forms.Label lbl_player;
        private System.Windows.Forms.Label lbl_type;
        private System.Windows.Forms.TextBox tb_matchid;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.ComboBox cb_thome;
        private System.Windows.Forms.ComboBox cb_taway;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_insert;
    }
}

