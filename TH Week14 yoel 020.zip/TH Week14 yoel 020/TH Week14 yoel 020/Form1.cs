﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week14_yoel_020
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;

        string sqlQuery;
        string sqlQuery2;
        string sqlQuery3;

        DataTable dtTim;
        DataTable dtteam1;
        DataTable dtteam2;
        DataTable player;
        DataTable dtdate;
        DataTable dgv;
        DataTable teamid;
        DataTable idplayer;

        string date;
        string temp;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtTim = new DataTable();
            sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
            sqlConnect.Open();
            sqlQuery = "SELECT team_name FROM team";


            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTim);
            cb_thome.DataSource = dtTim;

            cb_thome.DisplayMember = "team_name";

            dtteam1 = new DataTable();
            sqlDataAdapter.Fill(dtteam1);
            cb_taway.DataSource = dtteam1;


            cb_taway.DisplayMember = "team_name";
            sqlConnect.Close();


            cb_thome.SelectedIndex = -1;
            cb_taway.SelectedIndex = -1;

            dgv = new DataTable();


            dgv.Columns.Add("Minute");

            dgv.Columns.Add("Team");
            dgv.Columns.Add("Player");
            dgv.Columns.Add("Type");
            dgv.Columns.Add("Team_ID");


            cb_type.Items.Add("GO");
            cb_type.Items.Add("GP");
            cb_type.Items.Add("GW");
            cb_type.Items.Add("CR");
            cb_type.Items.Add("CY");
            cb_type.Items.Add("PM");
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            dgv.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
            dataGridView1.DataSource = dgv;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            dgv.Rows.RemoveAt(dataGridView1.CurrentCell.RowIndex);
            dataGridView1.DataSource = dgv;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            foreach (DataRow data in dgv.Rows)
            {


                try
                {
                    teamid = new DataTable();
                    string sqlQuery4 = $"Select team_id FROM team WHERE team_name = '{data[1].ToString()}';";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery4, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);

                    sqlDataAdapter.Fill(teamid);
                    sqlConnect.Close();

                    idplayer = new DataTable();
                    string sqlQuery5 = $"Select player_id FROM player WHERE player_name = '{data[2].ToString()}';";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery5, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(idplayer);
                    sqlConnect.Close();
                    MessageBox.Show($"VALUES ('{tb_matchid.Text}', '{data[0]}', '{teamid.Rows[0][0]}', '{idplayer.Rows[0][0]}', '{data[3]}', '0')");

                    //sqlQuery3 = $"INSERT INTO dmatch ('match_id', 'minute', 'team_id', 'player_id', 'type', 'delete') VALUES('{tbxMatchID.Text}', '{data[0]}', '{teamid.Rows[0][0]}', '{playerid.Rows[0][0]}', '{data[3]}', '0');";
                    sqlQuery3 = $"INSERT INTO dmatch VALUES('{tb_matchid.Text}', '{data[0]}', '{teamid.Rows[0][0]}', '{idplayer.Rows[0][0]}', '{data[3]}', '0');";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");


                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery3, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void cb_thome_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_team.Items.Clear();
            if (cb_thome.SelectedIndex == cb_taway.SelectedIndex)
            {
                MessageBox.Show("Select Another Team");
            }
            else
            {
                cb_team.Items.Add(cb_thome.Text);
                cb_team.Items.Add(cb_taway.Text);
            }
        }

        private void cb_taway_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_team.Items.Clear();
            if (cb_taway.SelectedIndex == cb_thome.SelectedIndex)
            {
                MessageBox.Show("Select Another Team");
            }
            else
            {
                cb_team.Items.Add(cb_thome.Text);
                cb_team.Items.Add(cb_taway.Text);
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            player = new DataTable();
            sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");

            sqlConnect.Open();
            sqlQuery = $"SELECT player.player_name FROM player, team WHERE player.team_id = team.team_id and team.team_name = '{cb_team.Text}' ;";

            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);

            sqlDataAdapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player_name";
            sqlConnect.Close();
            cb_player.SelectedIndex = -1;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dtdate = new DataTable();
            //date = dateTimePickerMatch.Value.ToString("yyyy-MM-DD");
            tb_matchid.Text = dateTimePicker1.Value.Year.ToString();
            try
            {
                sqlQuery2 = $"SELECT COUNT(match_id) FROM `match` WHERE match_id LIKE '{dateTimePicker1.Value.Year}%'";
                sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                sqlConnect.Open();


                sqlCommand = new MySqlCommand(sqlQuery2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtdate);
                int total = Convert.ToInt32(dtdate.Rows[0][0]) + 1;
                if (total < 0)
                {
                    temp = $"{dateTimePicker1.Value.Year}00{total}";

                }
                else if (total < 100)
                {
                    temp = $"{dateTimePicker1.Value.Year}0{total}";

                }
                else
                {
                    temp = $"{dateTimePicker1.Value.Year}{total}";

                }
                tb_matchid.Text = temp;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
